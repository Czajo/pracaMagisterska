# pracaMagisterskaDOC
#Maciej Czajkowski
20.04.2016 - initial commit
